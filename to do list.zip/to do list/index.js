'use strict';

let AddBtn = document.getElementById("addBtn");
let taskInput = document.getElementById("taskInput");

AddBtn.addEventListener('click', AddText);

function AddText() {
    let matn = taskInput.value;
    if (matn) {
        let listItem = document.createElement('li');
        listItem.innerHTML = `${matn} <button onclick="Remove(this)">Delete</button>`;
        document.getElementById("List").appendChild(listItem);
        taskInput.value = '';
    }
}

function Remove(element) {
    element.parentElement.remove(); 
}

function RemoveAll() {
    
    List.remove()
}